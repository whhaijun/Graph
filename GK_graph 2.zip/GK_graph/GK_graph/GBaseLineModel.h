//
//  GBaseLineModel.h
//  GK_graph
//
//  Created by  北斗国科 on 16/12/12.
//  Copyright © 2016年  北斗国科. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GBaseLineModel : NSObject

@property (nonatomic, copy) NSString *strTime;
@property (nonatomic, copy) NSString *strENum;
@property (nonatomic, copy) NSString *strNNum;
@property (nonatomic, copy) NSString *strUNum;
@end
