//
//  GGraphView.m
//  GK_graph
//
//  Created by  北斗国科 on 16/12/7.
//  Copyright © 2016年  北斗国科. All rights reserved.
//

#import "GGraphView.h"

@implementation GGraphView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
//        CGRectMake(0, 0, SCREEN_WIDTH, 27);
        
        [self setTitleLayer]; // 设置title
        [self configView]; // 初始化折线图
        [self bottomView]; // 折线图下方
    }
    return self;
}

- (void)setTitleLayer {
    // 沉降文字
    CGRect rect2 = CGRectMake(10, 2, CGRectGetWidth(self.frame)-20, 27);
    CATextLayer *heightLayer = [self layerStringRect:rect2 num:14];
    heightLayer.string = @"ENU显示(mm)";
    heightLayer.alignmentMode = kCAAlignmentLeft;
    [self.layer addSublayer:heightLayer];
}

- (void)bottomView {
    
    // 水平颜色
    CAShapeLayer *redLayer = [self colorRectRext:CGRectMake(30/2.0, (CGRectGetHeight(self.frame)-20)/2.0, 10, 10) color:SCRed];
    [self.layer addSublayer:redLayer];
    
    // 水平文字
    CGRect rect1 = CGRectMake(40+8, CGRectGetHeight(self.frame)-23, 20, 20);
    CATextLayer *CStrLayer = [self layerStringRect:rect1 num:10];
    CStrLayer.string = @"水平";
    [self.layer addSublayer:CStrLayer];
    
    // 沉降颜色
    CAShapeLayer *blueLayer = [self colorRectRext:CGRectMake(90/2.0, (CGRectGetHeight(self.frame)-20)/2.0, 10, 10) color:SCBlue];
    [self.layer addSublayer:blueLayer];

    // 沉降文字
    CGRect rect2 = CGRectMake(100+8, CGRectGetHeight(self.frame)-23, 20, 20);
    CATextLayer *heightLayer = [self layerStringRect:rect2 num:10];
    heightLayer.string = @"沉降";
    [self.layer addSublayer:heightLayer];
}

- (void)configView {
    _timeArr = [NSMutableArray array];
    _heightArr = [NSMutableArray array];
    _levelArr = [NSMutableArray array];
    
    if (chartView) {
        [chartView removeFromSuperview];
        chartView = nil;
    }
    //    path = indexPath;
    chartView = [[SCChart alloc] initwithSCChartDataFrame:CGRectMake(0, (self.frame.size.height-150)/2, self.frame.size.width, 150)
                                               withSource:self
                                                withStyle:SCChartLineStyle];
    [chartView showInView:self];
}

- (void)setTitle:(NSString *)title {
    _title = title;
}

- (void)setDataArrp:(NSArray *)dataArrp {
    _timeArr = dataArrp[0];
    _levelArr = dataArrp[1];
    _heightArr = dataArrp[2];
    
    [chartView strokeChart];
}

//横坐标标题数组
- (NSArray *)SCChart_xLableArray:(SCChart *)chart {
    return _timeArr;
}

//数值多重数组
- (NSArray *)SCChart_yValueArray:(SCChart *)chart {
    return @[_levelArr,_heightArr];

}

#pragma mark - @optional
//颜色数组
- (NSArray *)SCChart_ColorArray:(SCChart *)chart {
    return @[SCRed,SCBlue];
}

#pragma mark 折线图专享功能
//标记数值区域
- (CGRange)SCChartMarkRangeInLineChart:(SCChart *)chart {
    
    NSArray *arraylevel = [_levelArr sortedArrayUsingComparator:cmptr];
    CGFloat flevelmax = [[arraylevel lastObject] floatValue];
    CGFloat flevelmin = [[arraylevel firstObject] floatValue];
    
    NSArray *arrayheight = [_heightArr sortedArrayUsingComparator:cmptr];
    CGFloat fheightmax = [[arrayheight lastObject] floatValue];
    CGFloat fheightmin = [[arrayheight firstObject] floatValue];
    
    CGFloat max;
    
    if (flevelmax > fheightmax) {
        max = flevelmax;
    } else {
        max = fheightmax;
    }
    
    CGFloat min;
    
    if (flevelmin > fheightmin) {
        min = fheightmin;
    } else {
        min = flevelmin;
    }
    
    CGRange range;
    range.max = max;
    range.min = min;
    return range;
}

NSComparator cmptr = ^(id obj1, id obj2){
    if ([obj1 floatValue] > [obj2 floatValue]) {
        return (NSComparisonResult)NSOrderedDescending;
    }
    
    if ([obj1 floatValue] < [obj2 floatValue]) {
        return (NSComparisonResult)NSOrderedAscending;
    }
    return (NSComparisonResult)NSOrderedSame;
};

//判断显示横线条
- (BOOL)SCChart:(SCChart *)chart ShowHorizonLineAtIndex:(NSInteger)index {
    return YES;
}

//判断显示最大最小值
- (BOOL)SCChart:(SCChart *)chart ShowMaxMinAtIndex:(NSInteger)index {
    return NO;
}

// 画标注
- (CAShapeLayer *)colorRectRext:(CGRect)rect color:(UIColor *)color{
    CAShapeLayer *circle = [CAShapeLayer layer];
    circle.frame = rect;
    circle.fillColor = color.CGColor;
    circle.lineWidth = 2;
    circle.strokeColor = color.CGColor;
    
    UIBezierPath *circlePath = [UIBezierPath bezierPathWithRect:rect];
    circle.path = circlePath.CGPath;
    
    //    circle.path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(rect.origin.x, rect.origin.y) radius:rect.size.width startAngle:0 endAngle:2*M_PI clockwise:YES];
    
    return circle;
}

// 获取CATextLayer
- (CATextLayer *)layerStringRect:(CGRect)rect num:(CGFloat)num {
    CATextLayer *titleLayer = [CATextLayer layer];
    titleLayer.frame = rect;
    UIFont *font = [UIFont systemFontOfSize:num];
    CFStringRef fontnName = (__bridge CFStringRef)font.fontName;
    CGFontRef fontRef = CGFontCreateWithFontName(fontnName);
    titleLayer.font = fontRef;
    titleLayer.fontSize = font.pointSize;
    titleLayer.contentsScale = [UIScreen mainScreen].scale;
    CGFontRelease(fontRef);
    titleLayer.alignmentMode = kCAAlignmentCenter;
    titleLayer.foregroundColor = [UIColor blackColor].CGColor;
    
    return titleLayer;
}

@end
