//
//  PNChartLabel.h
//  PNChart
//
//  Created by 2014-763 on 15/3/12.
//  Copyright (c) 2015年 meilishuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCChartLabel : UILabel

@end
