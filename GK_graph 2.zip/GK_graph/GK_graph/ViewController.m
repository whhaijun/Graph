//
//  ViewController.m
//  GK_graph
//
//  Created by  北斗国科 on 16/12/7.
//  Copyright © 2016年  北斗国科. All rights reserved.
//

#import "ViewController.h"
#import "GGraphView.h"

#import "GBaseLineModel.h"

#ifdef DEBUG
#define NSLog(FORMAT, ...) fprintf(stderr,"\n %s:%d   %s\n",[[[NSString stringWithUTF8String:__FILE__] lastPathComponent] UTF8String],__LINE__, [[[NSString alloc] initWithData:[[NSString stringWithFormat:FORMAT, ##__VA_ARGS__] dataUsingEncoding:NSUTF8StringEncoding] encoding:NSNonLossyASCIIStringEncoding] UTF8String]);
#else
#define NSLog(...)
#endif

@interface ViewController ()

@property (nonatomic, strong) NSMutableArray *allDataArr;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *string = @"99999;DC20,2015/07/10 09:22:36.000,-0.1,  0.0,  0.1 ,-0.1 , 0.2 , -0.5";
    
    NSArray *arr = [string componentsSeparatedByString:@","];
    
    NSString *strStartData = [arr[1] substringFromIndex:12];
    NSString *timeData = [strStartData substringToIndex:7];
    
    NSString *eStr = arr[5];
    NSString *nStr = arr[6];
    NSString *uStr = arr[7];
    
    GBaseLineModel *model = [GBaseLineModel new];
    model.strTime = timeData;
    model.strENum = eStr;
    model.strNNum = nStr;
    model.strUNum = uStr;
    
    int num = 30;
    // 最大20点。
    _allDataArr = [[NSMutableArray alloc]initWithCapacity:20];
//    if (_allDataArr.count < 20) {
        for (int i = 0; i<num; i++) {
            [_allDataArr addObject:model];
        }
//    } else {
//        [_allDataArr removeObjectAtIndex:0];
//         [_allDataArr addObject:model];
//    }
    
    
//    NSLog(@"%.f", pow(3,2) ); //result 9 // 平方
//    NSLog(@"%.f", sqrt(16) ); //result 4 // 开方
    
//    int num = 20; // 最大20点。
    
    NSMutableArray *timeMarr = [[NSMutableArray alloc]initWithCapacity:20]; // 时间
    NSMutableArray *levelMarr = [[NSMutableArray alloc]initWithCapacity:20]; // 水平
    NSMutableArray *heightMarr = [[NSMutableArray alloc]initWithCapacity:20]; // 沉降
    for (GBaseLineModel *model in _allDataArr) {
        float fe = powf([model.strENum floatValue], 2);
        float fn = powf([model.strNNum floatValue], 2);
        NSString *strLevel = [NSString stringWithFormat:@"%.1f",sqrtf(fe+fn)];
        
        [timeMarr addObject:model.strTime];
        [levelMarr addObject:strLevel];
        [heightMarr addObject:model.strUNum];
    }
    
//    NSArray *dataArr = [strData componentsSeparatedByString:@"_  "];
    
    GGraphView *graphView = [[GGraphView alloc]initWithFrame:CGRectMake(0, 20, CGRectGetWidth(self.view.frame), 200)];
//    graphView.title = @"水平沉降图(mm)";
    graphView.dataArrp = @[timeMarr,levelMarr,heightMarr]; // 注意顺序（时间，水平，高度）
    
    [self.view addSubview:graphView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
