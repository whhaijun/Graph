//
//  GGraphView.h
//  GK_graph
//
//  Created by  北斗国科 on 16/12/7.
//  Copyright © 2016年  北斗国科. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SCChart.h"

@interface GGraphView : UIView <SCChartDataSource>
{
//    NSIndexPath *path;
    SCChart *chartView;
}

@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSArray *dataArrp;

@property (nonatomic, strong) NSMutableArray *timeArr;
@property (nonatomic, strong) NSMutableArray *levelArr;
@property (nonatomic, strong) NSMutableArray *heightArr;

@end
